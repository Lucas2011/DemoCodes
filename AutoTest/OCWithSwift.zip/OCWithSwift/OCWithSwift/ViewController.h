//
//  ViewController.h
//  OCWithSwift
//
//  Created by Lucas on 4/14/22.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

