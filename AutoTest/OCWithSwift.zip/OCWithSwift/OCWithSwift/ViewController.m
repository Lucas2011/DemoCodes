//
//  ViewController.m
//  OCWithSwift
//
//  Created by Lucas on 4/14/22.
//

#import "ViewController.h"
#import "OCWithSwift-Swift.h"
#import "testFramework/testFramework-Swift.h"


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    Dog * smallDog = [[Dog alloc] init];
    [smallDog bark];
    [smallDog.customer test1];
//    CustomClass * bb = [[CustomClass alloc] init];
//    [bb test1];
//    [bb test2];

}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
