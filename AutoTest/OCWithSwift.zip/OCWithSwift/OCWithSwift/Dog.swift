//
//  Dog.swift
//  OCWithSwift
//
//  Created by Lucas on 4/14/22.
//

import Foundation
import testFramework

@objc class Dog : NSObject {
    @objc public var customer:CustomClass
    
    override init() {
        self.customer = CustomClass()
        self.customer.name = "dog";
    }
    
    @objc  func bark(){
        print ("The dog is barking")
    }
    
    
}
