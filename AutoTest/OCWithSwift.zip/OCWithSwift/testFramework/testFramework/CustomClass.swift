//
//  CustomClass.swift
//  testFramework
//
//  Created by Lucas on 4/14/22.
//

import Foundation
public class CustomClass: NSObject {
public var name:String = ""
    
 @objc public func test1(){
         print("1")
     }
 //@objc+ private
      @objc
     private func test2(){
         print("2")
     }
}
